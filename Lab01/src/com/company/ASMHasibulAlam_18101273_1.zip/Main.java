package com.company;

public class Main
{
    public static void main(String[] args)
    {
        LexicalAnalyzer t=new LexicalAnalyzer();
        t.Analyze();
    }
}
